<?php require_once($rootPath.'/partials/head.php'); ?>
<?php require_once($rootPath.'/partials/header.php'); ?>

<?= $content?>

<?php require_once($rootPath.'/partials/footer.php'); ?>